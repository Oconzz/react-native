import React from 'react'
import TextoCentral from '../components/TextoCentral'

export default props => (
    <TextoCentral corFundo='#3b82c4'>
        Tela B
    </TextoCentral>
)