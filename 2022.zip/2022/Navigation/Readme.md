# Libs a serem instaladas

## Início com bottom tabs

yarn add @react-navigation/native
yarn add react-native-screens react-native-safe-area-context
yarn add react-native-vector-icons
yarn add @react-navigation/bottom-tabs

## Drawer 

yarn add @react-navigation/drawer
yarn add react-native-gesture-handler react-native-reanimated@2.2.4

## Stack

yarn add @react-navigation/stack