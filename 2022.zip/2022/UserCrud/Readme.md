# Libs a serem instaladas

- yarn add @react-navigation/native
- yarn add react-native-screens react-native-safe-area-context
- yarn add react-native-vector-icons
- yarn add @react-navigation/stack
- yarn add react-native-gesture-handler
- yarn add @react-native-masked-view/masked-view
- yarn add react-native-elements


"@react-native-community/masked-view": "^0.1.10",
"@react-navigation/native": "^5.7.3",
"@react-navigation/stack": "^5.9.0",
"react": "16.13.1",
"react-native": "0.63.2",
"react-native-elements": "^2.2.1",
"react-native-gesture-handler": "^1.7.0",
"react-native-reanimated": "^1.13.0",
"react-native-safe-area-context": "^3.1.6",
"react-native-screens": "^2.10.1",
"react-native-vector-icons": "^7.0.0"