export default [
    {
      id: 1,
      name: 'João Silva',
      email: 'josil@empmail.com',
      avatarUrl:
        'https://cdn.pixabay.com/photo/2016/11/18/23/38/child-1837375_960_720.png',
    },
    {
      id: 2,
      name: 'Mariana Aguiar',
      email: 'riamasil@empmail.com',
      avatarUrl:
        'https://cdn.pixabay.com/photo/2016/04/01/12/11/avatar-1300582_960_720.png',
    },
    {
      id: 3,
      name: 'Julio Fragoso',
      email: 'juliafral@empmail.com',
      avatarUrl:
        'https://cdn.pixabay.com/photo/2016/03/31/19/58/avatar-1295429_960_720.png',
    },
    {
      id: 4,
      name: 'Rafael Monteiro',
      email: 'rafamontee@empmail.com',
      avatarUrl:
        'https://cdn.pixabay.com/photo/2016/11/01/21/11/avatar-1789663_960_720.png',
    },
  ];
  